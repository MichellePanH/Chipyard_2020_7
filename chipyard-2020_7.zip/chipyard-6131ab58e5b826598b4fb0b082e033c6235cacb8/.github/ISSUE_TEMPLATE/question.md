---
name: Question
about: Ask a question
labels: question

---

<!--
    this type of issue is more for "how-tos", understanding chipyard, etc.
    if you find an error or issue with chipyard, please use the "Bug Report Issue".
-->

<!-- have you looked at the Chipyard documentation? -->
<!-- have you looked at the subproject documentation/githubs? -->
<!-- for example: -->
<!--   rocketchip: https://github.com/chipsalliance/rocket-chip/issues -->
<!--   boom: https://github.com/riscv-boom/riscv-boom/issues -->
<!--   firesim: https://github.com/firesim/firesim/issues -->
