---
name: Feature Request
about: Propose a change to Chipyard

---

<!-- choose one -->
**Impact**: rtl | software | unknown | other

**Description**
<!-- include detailed explanation, related issues, links for us to have context, ... -->

**What is a motivating example for changing the behavior?**
