---
name: Bug Report
about: Report a problem with Chipyard
labels: bug

---

<!-- choose one -->
**Impact**: rtl | software | unknown | other

**Tell us about your environment:**
*Chipyard Version:* <!-- 1.2.0, Hash: 2c0928 -->
*OS:* <!-- `Linux knight 4.4.0-92-generic #115-Ubuntu SMP Thu Aug 10 09:04:33 UTC 2017 x86_64 x86_64 x86_64 GNU/Linux` -->
*Other:* <!-- `prior steps taken/documentation followed/...` -->

**What is the current behavior?**

**What is the expected behavior?**

**Other information**
<!-- include detailed explanation, stacktraces, related issues, suggestions how to fix, links for us to have context, ... -->
