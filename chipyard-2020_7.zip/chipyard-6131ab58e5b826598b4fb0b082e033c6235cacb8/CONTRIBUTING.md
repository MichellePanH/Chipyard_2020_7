Contributing to Chipyard
=============================

### Branch management:

1) github:com/ucb-bar/chipyard: master = stable release. All merges to master must go through PR.
2) github:com/ucb-bar/chipyard: dev = pre-release non-stable branch with latest features. All merges to dev must go through PR.
3) Other dependencies pointed at by Chipyard (e.g. firesim, boom): master should be the version submoduled in ucb-bar/chipyard master.
