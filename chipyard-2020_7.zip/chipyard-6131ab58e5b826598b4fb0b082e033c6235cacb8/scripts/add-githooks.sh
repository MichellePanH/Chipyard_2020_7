#!/usr/bin/env bash

# adds githooks, expects to be run from base directory

git config core.hooksPath .githooks
